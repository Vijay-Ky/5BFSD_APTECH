interface Z
{
	Z()
	{
	}
}