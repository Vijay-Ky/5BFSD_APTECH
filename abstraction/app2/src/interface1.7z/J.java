interface J
{
	void test()
	{
	}
}