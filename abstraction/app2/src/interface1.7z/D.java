class D
{
}
abstract class E
{
}
interface F
{
}