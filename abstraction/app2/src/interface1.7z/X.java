interface X
{
	int i;
}