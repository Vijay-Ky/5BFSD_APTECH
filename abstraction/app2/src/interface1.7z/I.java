interface I
{
	abstract void test1();
	public void test2();
	public abstract void test3();
	abstract public void test4();
}