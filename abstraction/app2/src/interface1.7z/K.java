interface K
{
	K()
	{
	}
}