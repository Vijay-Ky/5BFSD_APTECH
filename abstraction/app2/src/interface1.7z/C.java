interface C
{
	static final int i = 10;
	static final int j = 20;
	final static int k = 30;

	abstract void test1();
	abstract void test2();
	abstract void test3();
	abstract void test4();
}