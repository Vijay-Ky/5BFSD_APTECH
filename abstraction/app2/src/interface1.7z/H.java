interface H
{
int test1();
void test2();
}