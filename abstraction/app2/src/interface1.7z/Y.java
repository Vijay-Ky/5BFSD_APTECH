interface Y 
{
	void test1()
	{
	}
}
